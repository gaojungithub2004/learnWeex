//
//  RecordButtonComponent.h
//  WeexEros
//
//  Created by ford Gao on 2019/11/29.
//  Copyright © 2019 benmu. All rights reserved.
//

#import "WXComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface RecordButtonComponent : WXComponent

@end

NS_ASSUME_NONNULL_END
