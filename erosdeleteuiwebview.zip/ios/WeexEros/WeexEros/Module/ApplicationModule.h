//
//  ApplicationModule.h
//  WeexEros
//
//  Created by ford Gao on 2019/6/13.
//  Copyright © 2019 benmu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WXModuleProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface ApplicationModule : NSObject<WXModuleProtocol>

@end

NS_ASSUME_NONNULL_END
