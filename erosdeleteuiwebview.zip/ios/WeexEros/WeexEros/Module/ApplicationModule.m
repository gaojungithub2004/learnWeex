//
//  ApplicationModule.m
//  WeexEros
//
//  Created by ford Gao on 2019/6/13.
//  Copyright © 2019 benmu. All rights reserved.
//

#import "ApplicationModule.h"
#import <WeexPluginLoader/WeexPluginLoader.h>

WX_PlUGIN_EXPORT_MODULE(application, ApplicationModule)

@implementation ApplicationModule
@synthesize weexInstance;

WX_EXPORT_METHOD(@selector(changeStatueBarStatus:))
WX_EXPORT_METHOD(@selector(changeLocalUrl:::))

- (void)changeStatueBarStatus: (NSDictionary *)params{
    
    if(params[@"status"]){
        if([params[@"status"] isEqualToString:@"0"]){
            //black
            [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
        }else{
            //white
            [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
        }
    }
}

- (void)changeLocalUrl: (NSString *)name :(NSString *)type :(NSString *)ref{
    
//    dispatch_async(dispatch_queue_create("com.wynter.customQueue", NULL), ^{
//        UIWebView *web = [weexInstance componentForRef: ref];
//        UIViewController *vc =  weexInstance.viewController;
//        UIView *view = vc.view;
//    });
    
    
    NSString *path = [[NSBundle mainBundle] pathForResource: name ofType: type];
    NSURL *url = [NSURL URLWithString: path];
}

@end
