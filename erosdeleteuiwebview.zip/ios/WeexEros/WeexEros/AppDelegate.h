//
//  AppDelegate.h
//  WeexEros
//
//  Created by XHY on 2017/8/7.
//  Copyright © 2017年 Byte Master. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <ErosPluginBaseLibrary/BMAppDelegate.h>

@interface AppDelegate : BMAppDelegate

@end

