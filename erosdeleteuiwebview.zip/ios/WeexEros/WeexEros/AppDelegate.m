//
//  AppDelegate.m
//  WeexEros
//
//  Created by XHY on 2017/8/7.
//  Copyright © 2017年 Byte Master. All rights reserved.
//

#import "AppDelegate.h"

#define Server APP_SERVER_ID
@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    BOOL result = [super application:application didFinishLaunchingWithOptions:launchOptions];
    
    //do something
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    NSLog(@"%@", Server);
    return result;
}

@end
