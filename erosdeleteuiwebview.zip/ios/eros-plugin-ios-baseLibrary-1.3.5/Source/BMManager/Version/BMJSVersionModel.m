//
//  BMJSVersionModel.m
//  BM-JYT
//
//  Created by XHY on 2017/2/28.
//  Copyright © 2017年 XHY. All rights reserved.
//

#import "BMJSVersionModel.h"

@implementation BMJSVersionModel

@end
