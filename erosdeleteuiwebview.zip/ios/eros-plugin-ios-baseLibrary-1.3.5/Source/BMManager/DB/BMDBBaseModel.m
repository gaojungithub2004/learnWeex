//
//  BMDBBaseModel.m
//  RealmDome
//
//  Created by XHY on 2017/3/31.
//  Copyright © 2017年 XHY. All rights reserved.
//

#import "BMDBBaseModel.h"

@implementation BMDBBaseModel

/* 设置 主键 */
+ (NSString *)primaryKey
{
    return @"key";
}

@end
