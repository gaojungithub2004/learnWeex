//
//  BMCheckUpdateProtocol.h
//  BMBaseLibrary
//
//  Created by XHY on 2018/6/28.
//

#import <Foundation/Foundation.h>

@protocol BMCheckUpdateProtocol <NSObject>

/** 检查更新 */
- (void)checkUpdate;

@end
