//
//  CTMediator+BMPayActions.h
//  BMBaseLibrary
//
//  Created by XHY on 2018/4/25.
//

#import "CTMediator.h"

@interface CTMediator (BMPayActions)

- (BOOL)CTMediator_PayHandleOpenURL:(NSDictionary *)info;

@end
