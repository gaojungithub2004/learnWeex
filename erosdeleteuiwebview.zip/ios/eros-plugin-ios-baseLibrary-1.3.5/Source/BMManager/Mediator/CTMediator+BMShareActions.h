//
//  CTMediator+BMShareActions.h
//  Pods
//
//  Created by XHY on 2018/4/25.
//

#import "CTMediator.h"

@interface CTMediator (BMShareActions)

- (BOOL)CTMediator_ShareHandleOpenURL:(NSDictionary *)info;

@end
