//
//  BMPlatformModel.m
//  Pods
//
//  Created by XHY on 2017/8/15.
//
//

#import "BMPlatformModel.h"

@implementation BMPlatformModelPage
@end

@implementation BMPlatformModelUrl
@end

@implementation BMPlatformModelGetui
@end

@implementation BMTabBarItem
@end

@implementation BMPlatformModelTabBar

+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"list" : [BMTabBarItem class]};
}

@end

@implementation BMPlatformModel
@end

