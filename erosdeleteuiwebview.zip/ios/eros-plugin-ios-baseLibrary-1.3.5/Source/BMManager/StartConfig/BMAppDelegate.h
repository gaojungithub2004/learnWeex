//
//  BMAppDelegate.h
//  BMBaseLibrary
//
//  Created by XHY on 2018/4/26.
//

#import <UIKit/UIKit.h>

@interface BMAppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic, strong) UIWindow *window;

@end
