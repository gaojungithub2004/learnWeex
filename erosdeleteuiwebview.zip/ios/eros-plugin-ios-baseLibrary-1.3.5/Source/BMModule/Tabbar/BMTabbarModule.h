//
//  BMTabbarModule.h
//  BMBaseLibrary
//
//  Created by XHY on 2018/6/21.
//

#import <Foundation/Foundation.h>
#import "WXModuleProtocol.h"

@interface BMTabbarModule : NSObject <WXModuleProtocol>

@end
