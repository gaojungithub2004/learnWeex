//
//  BMCommunicationModule.h
//  BMBaseLibrary
//
//  Created by XHY on 2017/12/27.
//

#import <Foundation/Foundation.h>
#import <WeexSDK.h>

@interface BMCommunicationModule : NSObject <WXModuleProtocol>

@end
