//
//  BMPickerModule.h
//  Pods
//
//  Created by 窦静轩 on 2017/5/5.
//
//

#import <Foundation/Foundation.h>
#import "WXModuleProtocol.h"

@interface BMPickerModule : NSObject <WXModuleProtocol,UIPickerViewDelegate>

@end
