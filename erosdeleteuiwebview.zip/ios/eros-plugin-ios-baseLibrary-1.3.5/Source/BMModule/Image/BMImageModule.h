//
//  BMImageModule.h
//  BMBaseLibrary
//
//  Created by XHY on 2017/12/29.
//

#import <Foundation/Foundation.h>
#import <WeexSDK.h>

@interface BMImageModule : NSObject <WXModuleProtocol>


@end
