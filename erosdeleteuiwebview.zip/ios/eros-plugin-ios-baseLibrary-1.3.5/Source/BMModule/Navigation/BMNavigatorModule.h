//
//  BMNavigatorModule.h
//  Pods
//
//  Created by XHY on 2017/5/16.
//
//

#import <Foundation/Foundation.h>
#import <WXModuleProtocol.h>

@interface BMNavigatorModule : NSObject <WXModuleProtocol>

@end
