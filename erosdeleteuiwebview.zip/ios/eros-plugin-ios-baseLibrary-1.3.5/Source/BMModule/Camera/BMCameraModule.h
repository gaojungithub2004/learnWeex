//
//  BMCameraModule.h
//  WeexDemo
//
//  Created by XHY on 2017/2/4.
//  Copyright © 2017年 taobao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WeexSDK.h>

@interface BMCameraModule : NSObject <WXModuleProtocol>

@end
