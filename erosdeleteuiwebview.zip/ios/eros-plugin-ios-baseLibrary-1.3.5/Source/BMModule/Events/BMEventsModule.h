//
//  BMEvents.h
//  BM-JYT
//
//  Created by 窦静轩 on 2017/3/28.
//  Copyright © 2017年 XHY. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WeexSDK.h>

@interface BMEventsModule : NSObject <WXModuleProtocol>

@end
