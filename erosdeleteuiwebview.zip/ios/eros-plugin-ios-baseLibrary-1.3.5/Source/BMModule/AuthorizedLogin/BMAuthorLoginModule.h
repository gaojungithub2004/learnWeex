//
//  BMAuthorLoginModule.h
//  Pods
//
//  Created by XHY on 2017/5/5.
//
//

#import <Foundation/Foundation.h>
#import <WeexSDK.h>

@interface BMAuthorLoginModule : NSObject <WXModuleProtocol>

@end
