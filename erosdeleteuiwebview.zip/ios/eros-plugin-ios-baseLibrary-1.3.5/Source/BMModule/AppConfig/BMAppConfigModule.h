//
//  BMAppConfigModule.h
//  BM-JYT
//
//  Created by XHY on 2017/3/13.
//  Copyright © 2017年 XHY. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WeexSDK.h>

@interface BMAppConfigModule : NSObject <WXModuleProtocol>

@end
