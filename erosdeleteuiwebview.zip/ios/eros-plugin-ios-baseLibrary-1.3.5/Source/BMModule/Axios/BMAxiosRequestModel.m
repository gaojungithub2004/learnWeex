//
//  BMAxiosRequestModel.m
//  WeexDemo
//
//  Created by XHY on 2017/1/13.
//  Copyright © 2017年 taobao. All rights reserved.
//

#import "BMAxiosRequestModel.h"

@implementation BMAxiosRequestModel

@end
