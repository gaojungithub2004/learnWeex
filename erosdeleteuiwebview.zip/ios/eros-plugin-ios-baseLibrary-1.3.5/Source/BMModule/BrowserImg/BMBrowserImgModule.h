//
//  BMBrowserImgModule.h
//  BM-JYT
//
//  Created by 窦静轩 on 2017/4/1.
//  Copyright © 2017年 XHY. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WeexSDK.h>

@interface BMBrowserImgModule : NSObject<WXModuleProtocol>

@end
