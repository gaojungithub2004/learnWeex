//
//  BMWebSocketDefaultImpl.h
//  BMBaseLibrary
//
//  Created by XHY on 2017/10/23.
//

#import <Foundation/Foundation.h>
#import "BMWebSocketHandler.h"

@interface BMWebSocketDefaultImpl : NSObject <BMWebSocketHandler>

@end
