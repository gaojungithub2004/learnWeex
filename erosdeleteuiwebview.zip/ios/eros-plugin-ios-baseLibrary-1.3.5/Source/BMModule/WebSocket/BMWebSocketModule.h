//
//  BMWebSocketModule.h
//  BMBaseLibrary
//
//  Created by XHY on 2017/10/23.
//

#import <Foundation/Foundation.h>
#import <WeexSDK.h>

@interface BMWebSocketModule : NSObject <WXModuleProtocol>

@end
