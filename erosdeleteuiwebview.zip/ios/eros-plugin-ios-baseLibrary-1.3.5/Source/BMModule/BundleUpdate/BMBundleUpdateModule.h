//
//  BMBundleUpdateModule.h
//  BMBaseLibrary
//
//  Created by XHY on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "WXModuleProtocol.h"

@interface BMBundleUpdateModule : NSObject <WXModuleProtocol>

@end
