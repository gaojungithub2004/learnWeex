//
//  BMToolsModule.h
//  BM-JYT
//
//  Created by XHY on 2017/4/17.
//  Copyright © 2017年 XHY. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WeexSDK.h>

@interface BMToolsModule : NSObject <WXModuleProtocol>

@end
