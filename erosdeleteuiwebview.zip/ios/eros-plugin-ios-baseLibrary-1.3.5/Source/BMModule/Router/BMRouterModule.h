//
//  BMRouterModule.h
//  WeexDemo
//
//  Created by XHY on 2017/1/11.
//  Copyright © 2017年 taobao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WeexSDK.h>


@interface BMRouterModule : NSObject <WXModuleProtocol>

@end
