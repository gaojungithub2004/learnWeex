//
//  BMConfigCenterHandler.h
//  BMBaseLibrary
//
//  Created by XHY on 2017/9/22.
//

#import <Foundation/Foundation.h>
#import "WXConfigCenterProtocol.h"

@interface BMConfigCenterHandler : NSObject <WXConfigCenterProtocol>

@end
