//
//  WXBMNetworkDefaultlpml.h
//  BM-JYT
//
//  Created by 窦静轩 on 2017/3/6.
//  Copyright © 2017年 XHY. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WeexSDK/WXResourceRequestHandler.h>

@interface WXBMNetworkDefaultlpml : NSObject<WXResourceRequestHandler, NSURLSessionDelegate>

@end
