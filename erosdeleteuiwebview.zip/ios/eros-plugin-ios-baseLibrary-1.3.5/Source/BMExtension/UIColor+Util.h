//
//  UIColor+Util.h
//  WeexDemo
//
//  Created by XHY on 2017/1/23.
//  Copyright © 2017年 taobao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (Util)

+ (UIColor *)colorWithHexString:(id)hexColorString;

@end
