//
//  UIWindow+Util.h
//  Pods
//
//  Created by XHY on 2017/7/12.
//
//

#import <UIKit/UIKit.h>

@interface UIWindow (Util)

/** 查询当前栈顶 window */
+ (UIWindow *)findVisibleWindow;

@end
