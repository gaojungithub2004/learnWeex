//
//  HYGuideView.h
//  BM-JYT
//
//  Created by XHY on 2017/2/23.
//  Copyright © 2017年 XHY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HYGuideView : UIView

+ (void)showInView:(UIView *)view;

@end
