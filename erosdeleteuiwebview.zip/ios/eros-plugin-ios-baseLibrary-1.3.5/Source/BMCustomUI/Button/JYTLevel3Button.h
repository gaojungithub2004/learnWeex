//
//  JYTLevel3Button.h
//  JingYitong
//
//  Created by saohuobang on 15/9/25.
//  Copyright © 2015年 XHY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JYTLevel3Button : UIButton

@end
