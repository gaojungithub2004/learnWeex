//
//  JYTLevel1Button.h
//  JingYitong
//
//  Created by XHY on 15/9/21.
//  Copyright © 2015年 XHY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JYTLevel1Button : UIButton

@end
