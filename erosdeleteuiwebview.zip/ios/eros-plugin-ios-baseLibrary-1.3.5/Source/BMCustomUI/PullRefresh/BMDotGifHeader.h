//
//  BMDotGifHeader.h
//  Pods
//
//  Created by XHY on 2017/5/9.
//
//

#import <MJRefresh/MJRefresh.h>

@interface BMDotGifHeader : MJRefreshGifHeader

@end
