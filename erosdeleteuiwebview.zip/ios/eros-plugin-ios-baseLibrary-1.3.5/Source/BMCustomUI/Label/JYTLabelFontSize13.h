//
//  JYTLabelFontSize13.h
//  JingYitong
//
//  Created by XHY on 16/5/30.
//  Copyright © 2016年 XHY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JYTLabelFontSize13 : UILabel

@end
