//
//  JYTBoldContentLabel.h
//  JingYitong
//
//  Created by XHY on 16/1/11.
//  Copyright © 2016年 XHY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JYTBoldContentLabel : UILabel

@end
