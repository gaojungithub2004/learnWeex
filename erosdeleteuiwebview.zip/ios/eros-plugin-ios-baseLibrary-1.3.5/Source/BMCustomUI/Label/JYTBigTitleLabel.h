//
//  JYTBigTitleLabel.h
//  JingYitong
//
//  Created by XHY on 15/9/22.
//  Copyright © 2015年 XHY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JYTBigTitleLabel : UILabel

@end
