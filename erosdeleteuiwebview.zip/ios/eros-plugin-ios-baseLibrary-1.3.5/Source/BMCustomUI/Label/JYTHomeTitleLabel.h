//
//  JYTHomeTitleLabel.h
//  JingYitong
//
//  Created by XHY on 16/6/13.
//  Copyright © 2016年 XHY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JYTHomeTitleLabel : UILabel

@end
