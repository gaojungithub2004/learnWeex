//
//  BMHotRefreshWebScoket.h
//  BMBaseLibrary
//
//  Created by XHY on 2018/3/15.
//
#ifdef DEBUG
#import <Foundation/Foundation.h>

@interface BMHotRefreshWebScoket : NSObject

- (void)connect;

- (void)close;

@end
#endif
