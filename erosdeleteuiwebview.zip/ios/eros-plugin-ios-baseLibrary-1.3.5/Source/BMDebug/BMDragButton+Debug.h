//
//  BMDragButton+Debug.h
//  BM-JYT
//
//  Created by 窦静轩 on 2017/3/10.
//  Copyright © 2017年 XHY. All rights reserved.
//

#ifdef DEBUG

#import "BMDragButton.h"

@interface BMDragButton(Debug)
+ (instancetype)debugButton;
@end

#endif
