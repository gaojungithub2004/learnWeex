//
//  BMChartComponent.h
//  BMBaseLibrary
//
//  Created by XHY on 2017/10/18.
//

#import <WeexSDK/WeexSDK.h>

@interface BMChartComponent : WXComponent

@end
