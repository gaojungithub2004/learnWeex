//
//  BMPopupComponent.h
//  Pods
//
//  Created by XHY on 2017/4/26.
//
//

#import <WeexSDK/WeexSDK.h>

@interface BMPopupComponent : WXComponent

@end
