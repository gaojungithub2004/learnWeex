//
//  BMMaskComponent.h
//  Pods
//
//  Created by XHY on 2017/4/27.
//
//

#import <WeexSDK/WeexSDK.h>

@interface BMMaskComponent : WXComponent

- (void)getPopViewRectNeedUpdateFrame:(BOOL)update;

@end
