//
//  BMRichTextComponent.h
//  Pods
//
//  Created by XHY on 2017/4/12.
//  Copyright © 2017年 XHY. All rights reserved.
//

#import <WeexSDK/WeexSDK.h>

@interface BMRichTextComponent : WXComponent

- (void)updateRichText;

@end
