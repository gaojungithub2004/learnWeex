//
//  BMCalendarComponent.h
//  BM-Doctor
//
//  Created by XHY on 2017/5/12.
//  Copyright © 2017年 XHY. All rights reserved.
//

#import <WeexSDK/WeexSDK.h>

@interface BMCalendarComponent : WXComponent

@end
