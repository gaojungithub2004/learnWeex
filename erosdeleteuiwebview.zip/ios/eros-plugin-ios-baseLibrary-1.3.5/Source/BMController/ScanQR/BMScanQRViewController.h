//
//  BMScanQRViewController.h
//  WeexDemo
//
//  Created by XHY on 2017/2/4.
//  Copyright © 2017年 taobao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WeexSDK/WeexSDK.h>

@interface BMScanQRViewController : UIViewController

@property (nonatomic, copy) WXModuleCallback callback;

@end
