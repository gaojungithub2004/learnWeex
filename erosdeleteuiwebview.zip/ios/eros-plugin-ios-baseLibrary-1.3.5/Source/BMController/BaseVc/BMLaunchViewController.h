//
//  BMLaunchViewController.h
//  BM-JYT
//
//  Created by XHY on 2017/2/20.
//  Copyright © 2017年 XHY. All rights reserved.
//

#import "BMBaseViewController.h"

@interface BMLaunchViewController : BMBaseViewController

@end
