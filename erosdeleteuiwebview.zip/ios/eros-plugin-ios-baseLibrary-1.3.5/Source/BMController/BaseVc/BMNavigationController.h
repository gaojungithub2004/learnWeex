//
//  BMNavigationController.h
//  WeexDemo
//
//  Created by XHY on 2017/1/12.
//  Copyright © 2017年 taobao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BMNavigationController : UINavigationController

@end
