//
//  WXListComponent+BMExtend.h
//  BM-JYT
//
//  Created by XHY on 2017/3/21.
//  Copyright © 2017年 XHY. All rights reserved.
//

#import <WeexSDK/WeexSDK.h>
#import <WeexSDK/WXListComponent.h>

@interface WXListComponent (BMExtend)

//- (instancetype)bmList_initWithRef:(NSString *)ref type:(NSString *)type styles:(NSDictionary *)styles attributes:(NSDictionary *)attributes events:(NSArray *)events weexInstance:(WXSDKInstance *)weexInstance;
//
//- (void)bmList_scrollViewDidScroll:(UIScrollView *)scrollView;

@end
