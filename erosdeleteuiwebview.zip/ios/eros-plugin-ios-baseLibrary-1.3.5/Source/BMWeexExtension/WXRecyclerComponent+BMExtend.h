//
//  WXRecyclerComponent+BMExtend.h
//  BMBaseLibrary
//
//  Created by XHY on 2017/9/22.
//

#import <WeexSDK/WeexSDK.h>
#import "WXRecyclerComponent.h"

@interface WXRecyclerComponent (BMExtend)

- (UIView *)bmRecycler_loadView;

@end
