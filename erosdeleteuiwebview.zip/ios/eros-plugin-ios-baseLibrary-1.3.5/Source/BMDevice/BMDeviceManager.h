//
//  BMDeviceManager.h
//  WeexDemo
//
//  Created by XHY on 2017/1/13.
//  Copyright © 2017年 taobao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BMDeviceManager : NSObject
/**
 *  设备标示
 *
 *  @return string
 */
+ (NSString *)deviceID;
@end
